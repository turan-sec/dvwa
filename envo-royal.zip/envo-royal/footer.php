</div><!-- end main-container -->
</div><!-- end page-area -->

<?php do_action('envo_royal_generate_footer'); ?>

</div><!-- end page-wrap -->

<?php wp_footer(); ?>

</body>
</html>
